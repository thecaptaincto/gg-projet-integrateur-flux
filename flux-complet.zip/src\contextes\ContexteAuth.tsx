import React, {createContext, useContext, useState, useEffect, ReactNode} from 'react';
import auth, {FirebaseAuthTypes} from '@react-native-firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';

import {
  estCourrielValide,
  estMotDePasseValideConnexion,
  estMotDePasseValideInscription,
} from '../utils/validationFormulaire';

interface ContexteAuthType {
  utilisateur: FirebaseAuthTypes.User | null;
  initialisation: boolean;
  chargement: boolean;
  premierLancement: boolean;
  courrielVerifie: boolean;
  inscrire: (email: string, motDePasse: string, nom: string) => Promise<void>;
  seConnecter: (email: string, motDePasse: string) => Promise<void>;
  envoyerCourrielVerification: () => Promise<void>;
  actualiserVerificationCourriel: () => Promise<void>;
  seConnecterAvecGoogle: () => Promise<void>;
  seDeconnecter: () => Promise<void>;
  reinitialiserMotDePasse: (email: string) => Promise<void>;
  completerPremierLancement: () => Promise<void>;
  genererCodeAcces: () => Promise<string>;
  codeAccesActif: boolean;
  codeAccesVerifie: boolean;
  activerCodeAcces: (actif: boolean) => Promise<void>;
  obtenirCodeAcces: () => Promise<string | null>;
  regenererCodeAcces: () => Promise<string>;
  verifierCodeAcces: (code: string) => Promise<void>;
}

const ContexteAuth = createContext<ContexteAuthType | undefined>(undefined);

export const FournisseurAuth = ({children}: {children: ReactNode}) => {
  const [utilisateur, setUtilisateur] = useState<FirebaseAuthTypes.User | null>(null);
  const [initialisation, setInitialisation] = useState(true);
  const [chargement, setChargement] = useState(false);
  const [premierLancement, setPremierLancement] = useState(true);
  const [courrielVerifie, setCourrielVerifie] = useState(false);
  const [codeAccesActif, setCodeAccesActif] = useState(false);
  const [codeAccesVerifie, setCodeAccesVerifie] = useState(false);
  const codeAccesRef = React.useRef<string | null>(null);
  const [authPret, setAuthPret] = useState(false);
  const [securitePrete, setSecuritePrete] = useState(false);

  useEffect(() => {
    let desabonner = () => {};

    try {
      desabonner = auth().onAuthStateChanged(user => {
        setUtilisateur(user);
        setCourrielVerifie(user?.emailVerified ?? false);
        setCodeAccesVerifie(false);
        setAuthPret(true);
      });
    } catch (erreur) {
      console.error("Erreur d'initialisation Firebase Auth:", erreur);
      setUtilisateur(null);
      setCourrielVerifie(false);
      setCodeAccesVerifie(false);
      setAuthPret(true);
    }

    const verifierPremierLancement = async () => {
      const valeur = await AsyncStorage.getItem('premierLancement');
      setPremierLancement(valeur === null);
    };

    const chargerSecurite = async () => {
      try {
        const [actif, codeLegacy] = await Promise.all([
          AsyncStorage.getItem('codeAccesActif'),
          AsyncStorage.getItem('codeAcces'),
        ]);
        setCodeAccesActif(actif === 'true');
        codeAccesRef.current = codeLegacy ?? null;
      } catch {
        // ignore
      } finally {
        setSecuritePrete(true);
      }
    };

    void verifierPremierLancement();
    void chargerSecurite();

    return desabonner;
  }, []);

  useEffect(() => {
    setInitialisation(!(authPret && securitePrete));
  }, [authPret, securitePrete]);

  useEffect(() => {
    if (!utilisateur) {
      setCodeAccesVerifie(false);
      return;
    }
    if (!courrielVerifie) {
      setCodeAccesVerifie(false);
      return;
    }
    if (!codeAccesActif) {
      setCodeAccesVerifie(true);
    }
  }, [codeAccesActif, courrielVerifie, utilisateur]);

  const obtenirCodeAcces = async (): Promise<string | null> => {
    if (codeAccesRef.current) {
      return codeAccesRef.current;
    }
    try {
      const code = await AsyncStorage.getItem('codeAcces');
      codeAccesRef.current = code;
      return code;
    } catch {
      return null;
    }
  };

  const genererNouveauCodeAcces = async (): Promise<string> => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    await AsyncStorage.setItem('codeAcces', code);
    codeAccesRef.current = code;
    return code;
  };

  const obtenirMessageErreur = (
    codeErreur: string,
    contexte: 'inscription' | 'connexion' | 'motdepasse' = 'connexion',
  ): string => {
    const messagesInscription: Record<string, string> = {
      'auth/email-already-in-use':
        'Cette adresse courriel est déjà utilisée. Essayez de vous connecter.',
      'auth/invalid-email': 'Adresse courriel invalide. Vérifiez le format.',
      'auth/weak-password':
        'Le mot de passe est trop faible. Utilisez au moins 8 caractères, une majuscule et un chiffre.',
      'auth/network-request-failed':
        'Erreur réseau. Vérifiez votre connexion Internet.',
    };

    const messagesConnexion: Record<string, string> = {
      'auth/user-not-found':
        "Aucun compte trouvé avec cette adresse. Créez un compte d'abord.",
      'auth/wrong-password': 'Mot de passe incorrect. Vérifiez votre saisie.',
      'auth/invalid-credential':
        'Courriel ou mot de passe incorrect. Vérifiez votre saisie.',
      'auth/invalid-email': 'Adresse courriel invalide. Vérifiez le format.',
      'auth/user-disabled': 'Ce compte a été désactivé. Contactez le support.',
      'auth/too-many-requests': 'Trop de tentatives. Réessayez plus tard.',
      'auth/network-request-failed':
        'Erreur réseau. Vérifiez votre connexion Internet.',
    };

    const messagesMotDePasse: Record<string, string> = {
      'auth/user-not-found':
        "Aucun compte trouvé avec cette adresse courriel.",
      'auth/invalid-email': 'Adresse courriel invalide.',
      'auth/network-request-failed':
        'Erreur réseau. Vérifiez votre connexion.',
    };

    let messages = messagesConnexion;
    if (contexte === 'inscription') messages = messagesInscription;
    if (contexte === 'motdepasse') messages = messagesMotDePasse;

    return (
      messages[codeErreur] ||
      "Une erreur inattendue s'est produite. Réessayez."
    );
  };

  const inscrire = async (email: string, motDePasse: string, nom: string) => {
    try {
      setChargement(true);

      const courrielNettoye = email.trim().toLowerCase();
      const nomNettoye = nom.trim();

      if (!estCourrielValide(courrielNettoye)) {
        throw new Error('Adresse courriel invalide');
      }
      if (!estMotDePasseValideInscription(motDePasse)) {
        throw new Error(
          'Le mot de passe doit contenir au moins 8 caractères, une majuscule et un chiffre',
        );
      }
      if (nomNettoye.length < 2) {
        throw new Error('Le nom doit contenir au moins 2 caractères');
      }

      const credential = await auth().createUserWithEmailAndPassword(
        courrielNettoye,
        motDePasse,
      );

      await credential.user.updateProfile({
        displayName: nomNettoye,
      });

      await credential.user.sendEmailVerification();
      setCourrielVerifie(credential.user.emailVerified);

      throw {
        code: 'success',
        message: `Inscription réussie !\n\nUn courriel de vérification a été envoyé à ${courrielNettoye}. Clique sur le lien reçu, puis reviens dans Flux.`,
      };
    } catch (erreur: any) {
      if (erreur.code === 'success') {
        throw erreur;
      }

      const message = erreur.code
        ? obtenirMessageErreur(erreur.code, 'inscription')
        : erreur.message || "Erreur lors de l'inscription";

      throw {code: 'error', message, firebaseCode: erreur.code};
    } finally {
      setChargement(false);
    }
  };

  const seConnecter = async (email: string, motDePasse: string) => {
    try {
      setChargement(true);

      const courrielNettoye = email.trim().toLowerCase();
      const motDePasseNettoye = motDePasse;

      if (!courrielNettoye || !motDePasseNettoye) {
        throw new Error('Veuillez remplir tous les champs');
      }
      if (!estCourrielValide(courrielNettoye)) {
        throw new Error('Adresse courriel invalide');
      }
      if (!estMotDePasseValideConnexion(motDePasseNettoye)) {
        throw new Error('Le mot de passe doit contenir au moins 6 caractères');
      }

      const credential = await auth().signInWithEmailAndPassword(
        courrielNettoye,
        motDePasseNettoye,
      );
      await credential.user.reload();
      const utilisateurRecharge = auth().currentUser ?? credential.user;
      setUtilisateur(utilisateurRecharge);
      setCourrielVerifie(utilisateurRecharge.emailVerified);
    } catch (erreur: any) {
      const message = erreur.code
        ? obtenirMessageErreur(erreur.code, 'connexion')
        : erreur.message || 'Erreur lors de la connexion';

      throw {code: 'error', message, firebaseCode: erreur.code};
    } finally {
      setChargement(false);
    }
  };

  const envoyerCourrielVerification = async () => {
    try {
      setChargement(true);
      const user = auth().currentUser;

      if (!user) {
        throw new Error('Aucun utilisateur connecté.');
      }

      await user.sendEmailVerification();

      throw {
        code: 'success',
        message: `Un courriel de vérification a été envoyé à ${user.email ?? ''}. Vérifie aussi les indésirables.`,
      };
    } catch (erreur: any) {
      if (erreur.code === 'success') {
        throw erreur;
      }

      throw {
        code: 'error',
        message:
          erreur.message ||
          "Erreur lors de l'envoi du courriel de vérification.",
      };
    } finally {
      setChargement(false);
    }
  };

  const actualiserVerificationCourriel = async () => {
    try {
      setChargement(true);
      const user = auth().currentUser;

      if (!user) {
        throw new Error('Aucun utilisateur connecté.');
      }

      await user.reload();
      const utilisateurRecharge = auth().currentUser ?? user;
      setUtilisateur(utilisateurRecharge);
      setCourrielVerifie(utilisateurRecharge.emailVerified);

      if (!utilisateurRecharge.emailVerified) {
        throw new Error(
          "Le courriel n'est pas encore vérifié. Clique sur le lien reçu, puis réessaie.",
        );
      }
    } finally {
      setChargement(false);
    }
  };

  const seConnecterAvecGoogle = async () => {
    try {
      setChargement(true);
      throw new Error(
        'La connexion avec Google sera disponible dans une prochaine mise à jour',
      );
    } catch (erreur: any) {
      throw {code: 'error', message: erreur.message};
    } finally {
      setChargement(false);
    }
  };

  const reinitialiserMotDePasse = async (email: string) => {
    try {
      const courrielNettoye = email.trim().toLowerCase();

      if (!courrielNettoye) {
        throw new Error('Veuillez entrer votre adresse courriel');
      }
      if (!estCourrielValide(courrielNettoye)) {
        throw new Error('Adresse courriel invalide.');
      }

      await auth().sendPasswordResetEmail(courrielNettoye);

      throw {
        code: 'success',
        message: `Email envoyé !\n\nUn lien de réinitialisation a été envoyé à ${courrielNettoye}. Vérifiez votre boîte de réception.`,
      };
    } catch (erreur: any) {
      if (erreur.code === 'success') {
        throw erreur;
      }

      const message = erreur.code
        ? obtenirMessageErreur(erreur.code, 'motdepasse')
        : erreur.message || "Erreur lors de l'envoi de l'email";

      throw {code: 'error', message, firebaseCode: erreur.code};
    }
  };

  const seDeconnecter = async () => {
    try {
      await auth().signOut();
      await AsyncStorage.removeItem('premierLancement');
      setPremierLancement(true);
      setCourrielVerifie(false);
      setCodeAccesVerifie(false);
    } catch (erreur: any) {
      throw {
        code: 'error',
        message: 'Erreur lors de la déconnexion',
        firebaseCode: erreur?.code,
      };
    }
  };

  const completerPremierLancement = async () => {
    try {
      await AsyncStorage.setItem('premierLancement', 'false');
      setPremierLancement(false);
    } catch (erreur) {
      console.error(
        'Erreur lors de la sauvegarde du premier lancement:',
        erreur,
      );
    }
  };

  const genererCodeAcces = async (): Promise<string> => {
    try {
      return await genererNouveauCodeAcces();
    } catch (erreur) {
      console.error('Erreur lors de la génération du code:', erreur);
      throw erreur;
    }
  };

  const regenererCodeAcces = async (): Promise<string> => {
    try {
      return await genererNouveauCodeAcces();
    } catch (erreur) {
      throw erreur;
    }
  };

  const activerCodeAcces = async (actif: boolean) => {
    setCodeAccesActif(actif);
    setCodeAccesVerifie(!actif);
    try {
      await AsyncStorage.setItem('codeAccesActif', actif ? 'true' : 'false');
      if (actif) {
        const code = await obtenirCodeAcces();
        if (!code) {
          await genererNouveauCodeAcces();
        }
      }
    } catch {
      // ignore
    }
  };

  const verifierCodeAcces = async (code: string) => {
    const codeNettoye = code.trim();
    const attendu = await obtenirCodeAcces();

    if (!codeAccesActif) {
      setCodeAccesVerifie(true);
      return;
    }
    if (!attendu) {
      throw new Error("Aucun code d'accès n'est défini.");
    }
    if (codeNettoye !== attendu) {
      throw new Error("Code d'accès incorrect.");
    }

    setCodeAccesVerifie(true);
  };

  return (
    <ContexteAuth.Provider
      value={{
        utilisateur,
        initialisation,
        chargement,
        premierLancement,
        courrielVerifie,
        inscrire,
        seConnecter,
        envoyerCourrielVerification,
        actualiserVerificationCourriel,
        seConnecterAvecGoogle,
        seDeconnecter,
        reinitialiserMotDePasse,
        completerPremierLancement,
        genererCodeAcces,
        codeAccesActif,
        codeAccesVerifie,
        activerCodeAcces,
        obtenirCodeAcces,
        regenererCodeAcces,
        verifierCodeAcces,
      }}>
      {children}
    </ContexteAuth.Provider>
  );
};

export const utiliserAuth = () => {
  const contexte = useContext(ContexteAuth);
  if (!contexte) {
    throw new Error('utiliserAuth doit être utilisé dans un FournisseurAuth');
  }
  return contexte;
};
